#expapp
1. Credentails
    
    UserName : demo

    Password : demo
	
2. Start the app in the browser
    
    http://localhost:8080/Khubani-Hitesh-expapp
	
3. You can refer recorded steps for getting familiar with functionality. 
	

