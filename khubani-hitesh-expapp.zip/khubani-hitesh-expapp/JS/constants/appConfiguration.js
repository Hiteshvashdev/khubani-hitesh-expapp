expApp.constant('appConfiguration', {    
    templatePath: '/templates/',    
    dashboard: '/expenseManagement',
    login: '/login'    
});

